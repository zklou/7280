.. powerlaw documentation master file, created by
   sphinx-quickstart on Tue Mar  8 11:44:35 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to powerlaw's documentation!
====================================

Here are documentation for the functions and classes in powerlaw. See the
`powerlaw home page <https://github.com/jeffalstott/powerlaw>`_ for more
information and examples.

Contents:

.. toctree::
   :maxdepth: 2

.. automodule:: powerlaw
    :members:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

